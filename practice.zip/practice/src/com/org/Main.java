package com.org;
import java.util.*;


public class Main {
	public static void main(String s[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the player details");
		String str=sc.nextLine();
		String details[]=str.split(",");
		String name=details[0];
		String country=details[1];
		String skill=details[2];
		Player p=new Player();
		p.setName(name);
		p.setCountry(country);
		p.setSkill(skill);
		System.out.println("Player Details : ");
		System.out.println("player Name : " +p.getName());
		System.out.println("Country Name : " +p.getCountry());
		System.out.println("Skill Name : " +p.getSkill());
		
	}

}

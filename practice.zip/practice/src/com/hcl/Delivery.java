package com.hcl;

public class Delivery {
	private long over;
	private long ball;
	private long runs;
	private String batsman;
	public String bowler;
	public String nonStriker;
	public Long getOver() {
		return over;
	}
	public void setOver(long over) {
		this.over = over;
	}
	public Long getBall() {
		return ball;
	}
	public void setBall(long ball) {
		this.ball = ball;
	}
	public Long getRuns() {
		return runs;
	}
	public void setRuns(long runs) {
		this.runs = runs;
	}
	public String getBatsman() {
		return batsman;
	}
	public void setBatsman(String batsman) {
		this.batsman = batsman;
	}
	public String getBowler() {
		return bowler;
	}
	public void setBowler(String bowler) {
		this.bowler = bowler;
	}
	public String getNonStriker() {
		return nonStriker;
	}
	public void setNonStriker(String nonStriker) {
		this.nonStriker = nonStriker;
	}
	void displayDeliveryDetails() {
		System.out.println("Delivery details");
		System.out.println(" over" +over);
		System.out.println(" ball" +ball);
		System.out.println("runs" +runs);
		System.out.println( "batsman name" +batsman);
		System.out.println("bowler name"+bowler);
		System.out.println("nonStriker name"+nonStriker);
		
	}
	

}

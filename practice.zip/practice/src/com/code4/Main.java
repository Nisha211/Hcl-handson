package com.code4;
import java.util.*;

import com.practice.Venue;

public class Main {

	public static void main(String[] args) {
		String name;
		String city;
		Scanner sc = new Scanner(System.in);
	    System.out.println("Enter the Venue name: ");
	    name=sc.nextLine();
	    System.out.println("Enter the  City name: ");
	    city=sc.nextLine();
	    Player v=new Player();
	    v.setName(name);
	    v.setCity(city);
	    System.out.println("Venue Details:");
	    System.out.println("Venue Name : " +v.getName());
	    System.out.println("City Name : " +v.getCity());
	    v.menu();
	    int a=sc.nextInt();
	    sc.nextLine();
	    switch(a) {
	    case 1:
		    System.out.println("Enter the Venue name: ");
		    name=sc.nextLine();
		    v.setName(name);
		    System.out.println("Venue Details:");
		    System.out.println("Venue Name : " +v.getName());
		    System.out.println("City Name : " +v.getCity());
		    v.menu();
		    break;
	    case 2:
		    System.out.println("Enter the  City name: ");
		    city=sc.nextLine();
		    v.setCity(city);
		    System.out.println("Venue Details:");
		    System.out.println("Venue Name : " +v.getName());
		    System.out.println("City Name : " +v.getCity());
		    v.menu();
		    break;
		 case 3:
			  System.out.println("Venue Details:");
			  System.out.println("Venue Name : " +v.getName());
			  System.out.println("City Name : " +v.getCity());
			  break;
			    
			  
		    	
	    	
	    }
	    int b=sc.nextInt();
	    sc.nextLine();
	    switch(b) {
	    case 1:
		    System.out.println("Enter the Venue name: ");
		    name=sc.nextLine();
		    v.setName(name);
		    System.out.println("Venue Details:");
		    System.out.println("Venue Name : " +v.getName());
		    System.out.println("City Name : " +v.getCity());
		    v.menu();
	    case 2:
		    System.out.println("Enter the  City name: ");
		    city=sc.nextLine();
		    v.setCity(city);
		    System.out.println("Venue Details:");
		    System.out.println("Venue Name : " +v.getName());
		    System.out.println("City Name : " +v.getCity());
		    v.menu();
		 case 3:
			    System.out.println("Venue Details:");
			    System.out.println("Venue Name : " +v.getName());
			    System.out.println("City Name : " +v.getCity());
			    break;
			  
	    
	   
		

	}
	    int c=sc.nextInt();
	    sc.nextLine();
	    switch(c) {
	    case 1:
		    System.out.println("Enter the Venue name: ");
		    name=sc.nextLine();
		    v.setName(name);
		    System.out.println("Venue Details:");
		    System.out.println("Venue Name : " +v.getName());
		    System.out.println("City Name : " +v.getCity());
		    v.menu();
	    case 2:
		    System.out.println("Enter the  City name: ");
		    city=sc.nextLine();
		    v.setCity(city);
		    System.out.println("Venue Details:");
		    System.out.println("Venue Name : " +v.getName());
		    System.out.println("City Name : " +v.getCity());
		    v.menu();
		 case 3:
			    System.out.println("Venue Details:");
			    System.out.println("Venue Name : " +v.getName());
			    System.out.println("City Name : " +v.getCity());
			    break;
			  

}
	}
}

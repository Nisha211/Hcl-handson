package player;
import java.util.*;

public class Main {
	public static void main(String args[]) {
		String player;
		String country;
		String skill;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the player name");
		player=sc.nextLine();
		System.out.println("Enter the country name");
		country=sc.nextLine();
		System.out.println("Enter the skill");
		skill=sc.nextLine();
		Player p=new Player();
		p.setName(player);
		p.setCountry(country);
		p.setSkill(skill);
		System.out.println("Player Details:");
		System.out.println("Player Name:" +p.getName());
		System.out.println("Country Name : " +p.getCountry());
		System.out.println("Skill : " +p.getSkill());
		
		
	}

}

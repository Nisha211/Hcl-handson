package com.code8;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		int i;
		Scanner sc=new Scanner(System.in);
		Wicket w=new Wicket();
	    System.out.println("Enter the number of wickets");
	    int n=sc.nextInt();
	    sc.nextLine();
	    for(i=0;i<=n;i++) {
	    	System.out.println("Enter the details");
	    	String details=sc.nextLine();
	    	String[] str=details.split(",");
			for(String s:str)
				System.out.println("");
	    	System.out.println("wicket detais");
	    	String a=str[0];
	    	long over=Long.parseLong(a);
	    	w.setOver(over);
	    	System.out.println("over : " +w.getOver());
	    	
	    	String b=str[1];
	    	long ball=Long.parseLong(b);
	    	w.setBall(ball);
	    	System.out.println("ball" +w.getBall());
	    	
	    	String wicketType=str[2];
	    	w.setWicketType(wicketType);
	    	System.out.println("wicketTyp : e" +w.getWicketType());
	    	
	    	String playerName=str[3];
	    	w.setPlayerName(playerName);
	    	System.out.println("playername : " +w.getPlayerName());
	    
	    	
	    	String bowlerName=str[4];
	    	w.setBowlerName(bowlerName);
	    	System.out.println("bowlername : " +w.getBowlerName());
	    	
	     	
	    	
	    }
	}

}

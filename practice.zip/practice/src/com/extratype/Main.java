package com.extratype;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		String str="wide#1";
		String details[]=str.split("#");
		String ExtraType=details[0];
		int Runs=Integer.parseInt(details[1]);
		System.out.println(ExtraType);
		System.out.println(Runs);

	}

}

package com.hcl2;

import java.util.*;


public class Main {

	public static void main(String[] args) {
		int product_code;
		String product_name;
	    double price;
		int stock;
		String staticname;
		Product i1=new Product();
		Product i2=new Product();
		Scanner sc=new Scanner(System.in);
		
		 System.out.println("Enter the product code");
		 product_code=sc.nextInt();
		 sc.nextLine();
		 i1.setProduct_code(product_code);
		 System.out.println("product_name");
		 product_name=sc.nextLine();
		 i1.setProduct_name(product_name);
		 System.out.println("product_price");
		 price=sc.nextDouble();
		 i1.setPrice(price);
		 System.out.println("stock");
		 stock=sc.nextInt();
		 i1.setStock(stock);
		 i1.setStaticname("l&k suppliers");
		
		 
		 product_code=sc.nextInt();
		 sc.nextLine();
		 i2.setProduct_code(product_code);
		 System.out.println("product_name");
		 product_name=sc.nextLine();
		 i2.setProduct_name(product_name);
		 System.out.println("product_price");
		 price=sc.nextDouble();
		 i2.setPrice(price);
		 System.out.println("stock");
		 stock=sc.nextInt();
		 i2.setStock(stock);
		 i2.setStaticname("l&k suppliers");
		 System.out.println("product_code" +i1.getProduct_code());
		 System.out.println("product_name" +i1.getProduct_name());
		 System.out.println("price" +i1.getPrice());
		 System.out.println("stock" +i1.getStock());
		 System.out.println("product_code" +i2.getProduct_code());
		 System.out.println("product_name" +i2.getProduct_name());
		 System.out.println("price" +i2.getPrice());
		 System.out.println("stock" +i2.getStock());
		 i1.getDiscountedPrice(i1);
		 i2.getDiscountedPrice(i2);
	
		
		 Product checkprice=new Product();
		 checkprice.Checkprice(i1,i2);	

	}

}

package com.hcl3;
import java.util.*;


public class Main {
	private static int b =5;

	public static void main(String[] args) {
		int i;
	     Product[] obj=new Product[b];
	     
	     for(i=0;i<b;i++) {
	    	 Product p=buildProduct();
	    	 obj[i]=p;
	     }
	     for(i=0;i<b;i++) {
	    	 Product p=buildProduct();
	    	 Product item=obj[i];
	    	 display(item);
	     }
	     for(i=0;i<b;i++) {
	    	 
	     }
	     
	     

	}
public static void display(Product item) {
	System.out.println("Product_code"  +item.getProduct_code());
	System.out.println("product_name" +item.getProduct_name());
	System.out.println("price"  +item.getPrice());
	System.out.println("stock" +item.getStock());
}




public static Product buildProduct() {
	 int product_code;
	 String Product_name;
	 double price;
	 int stock;
	 String staticname;
	 Scanner sc=new Scanner(System.in);
	 Product p=new Product();
	 System.out.println("enter the product code");
	 product_code=sc.nextInt();
	 sc.nextLine();
	 p.setProduct_code(product_code);
	 System.out.println("enter the product name");
	 Product_name=sc.nextLine();
	 p.setProduct_name(Product_name);
	 System.out.println("enter the product price");
	 price=sc.nextDouble();
	 sc.nextLine();
	 p.setPrice(price);
	 System.out.println("enter the stock");
	 stock=sc.nextInt();
	 sc.nextLine();
	 p.setStock(stock);
	 
	 return p;
	

}
}
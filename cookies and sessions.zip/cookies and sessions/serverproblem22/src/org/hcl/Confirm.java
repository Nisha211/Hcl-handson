package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Confirm")
public class Confirm extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public Confirm() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();

		String seats = request.getParameter("seats");
		Integer tickets = Integer.parseInt(request.getParameter("tickets"));

		Integer rate = 0;

		if (seats.equals("Platinum")) {

			rate = 300 * tickets;

		} else if (seats.equals("Gold")) {

			rate = 250 * tickets;

		} else if (seats.equals("Silver")) {

			rate = 150 * tickets;

		} else if (seats.equals("Bronze")) {

			rate = 100 * tickets;

		}

		Cookie type = new Cookie("seats", seats);
		Cookie count = new Cookie("tickets", tickets.toString());
		Cookie ticketcost = new Cookie("rate", rate.toString());
		response.addCookie(type);
		response.addCookie(count);
		response.addCookie(ticketcost);
		pw.println("<center>");

		pw.println("<h1>Ticket Confirmation</h1>");
		pw.println("<The ticket rate is" + rate + "<br>");
		pw.println("Do you want to confirm your ticket?</div>");
		pw.println("<form action='./Display' method='post' style='text-align:center;'>");
		pw.println("<input type='submit' value='Confirm' id='confirm'></form>");
		pw.println("<form action='./Index' method='get' style='text-align:center;'>");
		pw.println("<input type='submit' value='Cancel' id='cancel'></form>");
		pw.println("</center>");
		pw.close();

	}

}

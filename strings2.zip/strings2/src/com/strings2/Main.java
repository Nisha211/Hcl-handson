package com.strings2;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date");
		String date1=sc.nextLine();
		
		if(date1.contains("*")) {
			String date2=date1.replace("*", "-");
			System.out.println("Enter the date in correct format   "+date2);
		}
		else if(date1.contains("/")) {
			String date3=date1.replace("/", "-");
			System.out.println("Enter the date in correct format   "+date3);
			
		}
		else {
			String date4=date1.replace("", "-");
			System.out.println("Enter the date in correct format    "+date4);
		}
	
         
     
       
	}


	}

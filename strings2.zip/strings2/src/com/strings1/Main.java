package com.strings1;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter address1 details");
		String address1=sc.nextLine();
		System.out.println("enter address2 details");
		String address2=sc.nextLine();
		if(address1.contentEquals(address2)) {
			System.out.println("RED");
		}
		else if(address1.equalsIgnoreCase(address2)) {
			System.out.println("BLUE");
		}
		else {
			System.out.println("GREEN");
		}
	
		
		
	}

}

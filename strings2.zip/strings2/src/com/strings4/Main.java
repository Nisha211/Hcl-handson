package com.strings4;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of users");
		int a=sc.nextInt();
		sc.nextLine();
		String name[]=new String[a];
		System.out.println("enter user address details");
		for(int i=0;i<a;i++) {
			name[i]=sc.nextLine();
		}
		for(int i=0;i<a;i++) {
			String details[]=name[i].split(",");
			int userID=Integer.parseInt(details[0]);
			String Street=details[1];
			String city=details[2];
			String state=details[3];
			System.out.format("%-15s %-15s %-15s %s\n",userID, Street ,city,state);
		}
		

	}

}

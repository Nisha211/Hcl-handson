package com.string5;
import java.util.*;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		String str=sc.nextLine();
		StringBuilder builder=new StringBuilder(str);
		boolean isLastSpace=true;
		for(int i=0;i<builder.length();i++) {
			char ch = builder.charAt(i);
            if(isLastSpace && ch >= 'a' && ch <='z')
            {
                builder.setCharAt(i, (char)(ch + ('A' - 'a') ));
                isLastSpace = false;
            }
            else if (ch != ' ')
                isLastSpace = false;
            else
                isLastSpace = true;
        }
		str=builder.toString();
		str = str.replaceAll("\\s", "");
		System.out.println(str);
    
		}
}
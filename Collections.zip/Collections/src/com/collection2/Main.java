package com.collection2;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		ArrayList <ItemType> items=new ArrayList<>();
		ItemTypeService item=new ItemTypeService(items);
		String name1;
		double deposit1;
		double costperday1;
		String answer="";
		do {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the name");
			name1=sc.nextLine();
			System.out.println("enter deposit");
			deposit1=sc.nextDouble();
			System.out.println("enter costperday");
			costperday1=sc.nextDouble();
			item.insert(new ItemType(name1,deposit1,costperday1));
			answer=sc.next();	
			
		}while(answer.equals("yes"));
		
		
		System.out.println("name deposit costperday");
		item.display();

	}

}

package com.collection2;
import java.util.*;

public class ItemTypeService {
	ArrayList<ItemType> items=null;

	public ItemTypeService(ArrayList<ItemType> items) {
		super();
		this.items = items;
	}
	public boolean insert(ItemType i) {
		boolean b=items.add(i);
		return b;
	}
	public void display() {
		Iterator itr=items.iterator();
		while(itr.hasNext()) {
			ItemType i=(ItemType)itr.next();
			System.out.println(i);
		}
	}

}

package com.collection7;
import java.util.*;

public class UserBO extends ArrayList<User> {
	static UserBO u=new UserBO();
	void remove(int n1,int n2) {
		removeRange(n1,n2);
	}
	static UserBO getList() {
		u.add(new User("mohan raja","9874563210","mohan","mohan@abc.in"));
		u.add(new User("Arjun Ravi","4324237","arjun","arjun@abc.in"));
		u.add(new User("Arun Kumar","9845671230","arun","arun@abc.in"));
		u.add(new User("PrakashRash", "754891234","Parkash","raj@abc.in"));
		u.add(new User("RamGanesh","9874587457","Ram","ramg@abc.in"));
		
		return u;
	}

}

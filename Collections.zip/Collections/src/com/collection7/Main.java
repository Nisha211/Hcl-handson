package com.collection7;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Main {

	public static void main(String[] args)throws NumberFormatException,IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		UserBO user=new UserBO();
		user.addAll(user.getList());
		System.out.println("enter the user details");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++) {
			System.out.println("enter the details in csv format");
			String s=br.readLine();
			String[] details=s.split(",");
			user.add(new User(details[0],details[1],details[2],details[3]));	
		}
		Iterator <User> i=user.iterator();
		User u=new User();
		System.out.format("%-20s%-20s%-20s%-20s","name","contact number","username","email");
		while(i.hasNext()) {
			u=i.next();
			u.display();
			
		}
		System.out.println("enter the removal of range");
		int remove1,remove2;
		remove1=Integer.parseInt(br.readLine());
		remove2=Integer.parseInt(br.readLine());
		user.remove(remove1,remove2);
		Iterator<User> i1=user.iterator();
		User u1=new User();
		System.out.format("%-20s%-20s%-20s%-20s","name","contact number","username","email");
		while(i1.hasNext()) {
			u1=i1.next();
			u1.display();
			
		}

	}

}

package com.collection4;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Set<String> set=new HashSet<String>();
		Scanner sc=new Scanner(System.in);
		String answer="";
		int count=0;
		do {
			System.out.println("enter the username");
			set.add(sc.next());
			System.out.println("do you want to continue");
			answer=sc.next();
				
		}while(answer.equals("yes"));
		System.out.println("the unique numbers are" +set.size());

	}

}

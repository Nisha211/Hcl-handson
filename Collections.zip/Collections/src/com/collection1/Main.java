package com.collection1;
import java.util.*;

public class Main {

	public static void main(String[] args) {
	        ArrayList<String> name = new ArrayList<String>();

	        Scanner scanner = new Scanner(System.in);
	        String answer = "";

	        {
	            do {
	                System.out.println("Please enter your name: ");
	                name.add(scanner.next());
	                System.out.println("Do you want to add a name yes/no?");
	                answer = scanner.next();
	            } while (answer.equals("yes"));
	            	System.out.println("the names entered are");
	            	for (int i = 0; i < name.size(); i++) {
	                System.out.print(name.get(i)+"\t");
	                System.out.println("");
	            }
	            }
	    }
}
		


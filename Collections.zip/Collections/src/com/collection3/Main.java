package com.collection3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter no of halls");
		int a=sc.nextInt();
		ArrayList<String>  halls=new ArrayList<>();
		for(int i=0;i<a;i++) {
			System.out.println("enter the hall name " +i);
			halls.add(sc.next());	
		}
		System.out.println("enter the hall name to be searched");
		String name=sc.next();
		if(halls.contains(name)) {
			int pos=halls.indexOf(name);
			System.out.println(halls.get(pos)+ " is found in the position "+ pos);
		}
		else {
			System.out.println("hall is not found");
		}
	}

}

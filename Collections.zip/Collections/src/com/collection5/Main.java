package com.collection5;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		HashSet<String> set1=new HashSet<>();
		Scanner scanner = new Scanner(System.in);
        String answer = "";

        {
            do {
                System.out.println("Please enter your name: ");
                set1.add(scanner.next());
                System.out.println("Do you want to add a name yes/no?");
                answer = scanner.next();
            } while (answer.equals("yes"));
            System.out.println("the unique numbers are" +set1.size());
            }
            }
		

}

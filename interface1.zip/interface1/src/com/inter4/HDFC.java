package com.inter4;

public class HDFC implements MutualFund {
	private int interestrate;
	private int amount;
	private int tenure;

	public HDFC() {

	}

	public HDFC(int interestrate, int amount, int tenure) {
		super();
		this.interestrate = interestrate;
		this.amount = amount;
		this.tenure = tenure;
	}

	public int getInterestrate() {
		return interestrate;
	}

	public void setInterestrate(int interestrate) {
		this.interestrate = interestrate;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public int getTenure() {
		return tenure;
	}

	public void setTenure(int tenure) {
		this.tenure = tenure;
	}

	public void duration() {

	}

	public void amount() {
		double value = (amount * interestrate * tenure);
		double interest = value / 100;
		System.out.println("the interest rate is" + interest);

	}

}

package com.inter4;

interface MutualFund {
	public void amount();

	public void duration();

}

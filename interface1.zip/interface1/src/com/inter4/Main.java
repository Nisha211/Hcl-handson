package com.inter4;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int amount = sc.nextInt();
		sc.nextLine();
		int year = sc.nextInt();
		sc.nextLine();
		int tenure = sc.nextInt();
		sc.nextLine();
		int bank = sc.nextInt();
		sc.nextLine();
		switch (bank) {
		case 1:
			MutualFund m = new AxisBank(amount, year, tenure);
			m.amount();
			break;
		case 2:
			MutualFund h = new HDFC(amount, year, tenure);
			h.amount();
			break;
		case 3:
			MutualFund ic = new ICICI(amount, year, tenure);
			ic.amount();
			break;

		}
	}

}

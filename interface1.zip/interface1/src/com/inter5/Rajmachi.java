package com.inter5;

public class Rajmachi implements Fort{
	
	public void distance() {
		System.out.println("the distance is 55Km");
		
	}

}

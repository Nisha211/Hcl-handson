package com.inter5;

public class Murud  implements Fort{
	public void distance() {
		System.out.println("the distance is 93Km");
		
	}
	

}

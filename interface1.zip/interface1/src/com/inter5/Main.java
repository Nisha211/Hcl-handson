package com.inter5;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("what do you want to visit");
		System.out.println("1.Rajmachi");
		System.out.println("2.Shivgadh");
		System.out.println("3.Murud");
		
		
		int fort=sc.nextInt();
		sc.nextLine();
		switch(fort) {
		case 1:
			System.out.println("you have  choosed Rajmachi");
			Fort f=new Rajmachi();
			f.distance();
			break;
		case 2:
			System.out.println("you have choosed Shivgadh");
			Fort s=new Shivgadh();
			s.distance();
			break;
		case 3:
			System.out.println("you have choosed Murud");
			Fort m=new Murud();
			m.distance();
			break;
		}
	}

}

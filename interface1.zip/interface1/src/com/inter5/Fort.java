package com.inter5;

interface Fort{
	public void distance();
}
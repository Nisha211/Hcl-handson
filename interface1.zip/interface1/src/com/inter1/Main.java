package com.inter1;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter length and breadth of rectangle");
		System.out.println("enter the length of a rectangle");
		double a=sc.nextDouble();
		sc.nextLine();
		System.out.println("enter the breadth of a rectangle");
		double b=sc.nextDouble();
		sc.nextLine();
		System.out.println("enter the side of a square");
		double c=sc.nextDouble();
		sc.nextLine();
		Polygon p=new Rectangle(a,b);
		p.calcPeri();
		p.calcArea();
		Polygon s=new Square(c);
		s.calcPeri();
		s.calcArea();
	

	}

}

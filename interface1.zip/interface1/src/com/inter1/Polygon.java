package com.inter1;

interface Polygon {
	public void calcPeri();
	public void calcArea();

}

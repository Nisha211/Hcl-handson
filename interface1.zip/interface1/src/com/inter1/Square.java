package com.inter1;

public class Square implements Polygon {
	private double side;
	
	public Square() {
		
	}
	
	public Square(double side) {
		super();
		this.side = side;
	}
	

	public double getSide() {
		return side;
	}

	public void setSide(double side) {
		this.side = side;
	}

	public void calcPeri() {
		double perimeter=4*side;
		System.out.println("perimeter of a square"+perimeter);
		
	}
	
	public void calcArea() {
		double area=side*side;
		System.out.println("area of a square" +area);
		
	}
	

}

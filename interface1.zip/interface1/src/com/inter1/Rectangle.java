package com.inter1;

public class Rectangle implements Polygon {
	public double length;
	public double breadth;
	
	public Rectangle() {
		
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}
	public double getBreadth() {
		return breadth;
	}
	public void setBreadth(double breadth) {
		this.breadth = breadth;
	}
	public Rectangle(double length, double breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}
	public void calcPeri() {
		double perimeter=2*(length+breadth);
		System.out.println("perimeter of a rectangle" +perimeter);
		
	}
	public void calcArea() {
		double area=length*breadth;
		System.out.println("area of a rectangle"+area);
		
	}
	
	

}

package com.inter;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("1.gold stall,2.premium stall,3.executive stall");
		int a = sc.nextInt();
		sc.nextLine();
		switch (a) {
		case 1:
			System.out.println("enter the stall details");
			String str = sc.nextLine();
			String details[] = str.split(",");
			Stall s = new Gold_Stall(details[0], Integer.parseInt(details[1]), details[2],
					Integer.parseInt(details[3]));
			s.display();
			break;

		case 2:
			System.out.println("enter the stall details");
			String str1 = sc.nextLine();
			String details1[] = str1.split(",");
			Stall s1 = new Premium_Stall(details1[0], Integer.parseInt(details1[1]), details1[2],
					Integer.parseInt(details1[3]));
			s1.display();
			break;

		case 3:
			System.out.println("enter the stall details");
			String str2 = sc.nextLine();
			String details2[] = str2.split(",");
			Stall s2 = new ExecutiveStall(details2[0], Integer.parseInt(details2[1]), details2[2],
					Integer.parseInt(details2[3]));
			s2.display();
			break;

		}

		int b = sc.nextInt();
		sc.nextLine();
		switch (b) {
		case 1:
			System.out.println("enter the stall details");
			String str = sc.nextLine();
			String details[] = str.split(",");
			Stall s = new Gold_Stall(details[0], Integer.parseInt(details[1]), details[2],
					Integer.parseInt(details[3]));
			s.display();
			break;

		case 2:
			System.out.println("enter the stall details");
			String str1 = sc.nextLine();
			String details1[] = str1.split(",");
			Stall s1 = new Premium_Stall(details1[0], Integer.parseInt(details1[1]), details1[2],
					Integer.parseInt(details1[3]));
			s1.display();
			break;

		case 3:
			System.out.println("enter the stall details");
			String str2 = sc.nextLine();
			String details2[] = str2.split(",");
			Stall s2 = new ExecutiveStall(details2[0], Integer.parseInt(details2[1]), details2[2],
					Integer.parseInt(details2[3]));
			s2.display();
			break;

		}

		int c = sc.nextInt();
		sc.nextLine();
		switch (c) {
		case 1:
			System.out.println("enter the stall details");
			String str = sc.nextLine();
			String details[] = str.split(",");
			Stall s = new Gold_Stall(details[0], Integer.parseInt(details[1]), details[2],
					Integer.parseInt(details[3]));
			s.display();
			break;

		case 2:
			System.out.println("enter the stall details");
			String str1 = sc.nextLine();
			String details1[] = str1.split(",");
			Stall s1 = new Premium_Stall(details1[0], Integer.parseInt(details1[1]), details1[2],
					Integer.parseInt(details1[3]));
			s1.display();
			break;

		case 3:
			System.out.println("enter the stall details");
			String str2 = sc.nextLine();
			String details2[] = str2.split(",");
			Stall s2 = new ExecutiveStall(details2[0], Integer.parseInt(details2[1]), details2[2],
					Integer.parseInt(details2[3]));
			s2.display();
			break;

		}

	}
}

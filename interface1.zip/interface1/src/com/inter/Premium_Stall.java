package com.inter;

public class Premium_Stall implements Stall {

	private String stallName;
	private int cost;
	private String ownerName;
	private int projector;

	public void display() {
		System.out.println("stallname : " + getStallName());
		System.out.println("stallcost : " + getCost());
		System.out.println("owner name : " + getOwnerName());
		System.out.println("no of projectors : " + getProjector());

	}

	public Premium_Stall() {

	}

	public Premium_Stall(String stallName, int cost, String ownerName, int projector) {
		super();
		this.stallName = stallName;
		this.cost = cost;
		this.ownerName = ownerName;
		this.projector = projector;
	}

	public String getStallName() {
		return stallName;
	}

	public void setStallName(String stallName) {
		this.stallName = stallName;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public int getProjector() {
		return projector;
	}

	public void setProjector(int projector) {
		this.projector = projector;
	}

}

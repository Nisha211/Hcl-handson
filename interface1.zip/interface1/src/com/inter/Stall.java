package com.inter;

interface Stall {
	void display();

}

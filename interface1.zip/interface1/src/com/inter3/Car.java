package com.inter3;

interface Car {
	public void sum();

	public void years();

	public void brand();

}
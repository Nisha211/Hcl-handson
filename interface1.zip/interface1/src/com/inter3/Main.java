package com.inter3;

public class Main {

	public static void main(String[] args) {
		Car c = new Service();
		c.sum();
		c.years();
		c.brand();

	}

}

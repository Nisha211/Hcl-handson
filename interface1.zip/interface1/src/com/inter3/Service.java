package com.inter3;

import java.util.*;

public class Service implements Car {
	Scanner sc = new Scanner(System.in);

	public void sum() {
		int temp = 0, sum = 0, rem;
		System.out.println("enter your car number");
		int a = sc.nextInt();
		sc.nextLine();
		temp = a;
		while (temp > 0) {
			rem = temp % 10;
			sum = sum + rem;
			temp = temp / 10;
		}
		if (sum % 2 == 0) {
			System.out.println("you can come on Tuesday,Thursday,Saturday");
		} else {
			System.out.println("You can come on Monday,Wednesday,Friday");
		}
	}

	public void years() {
		System.out.println("how many years old car you have ");
		int years = sc.nextInt();
		sc.nextLine();
		if (years < 5) {
			System.out.println("you are not eligible for free washing");
		} else {
			System.out.println("you are eligible for washing");
		}

	}

	public void brand() {
		System.out.println("enter the brand name");
		String brand = sc.nextLine();
		double serviceCharge = 5000;
		if (brand.equalsIgnoreCase("maruthi")) {
			double Charge = (0.05 * 5000);
			serviceCharge = 5000 - Charge;
			System.out.println("your service charges are" + serviceCharge);
		} else {
			System.out.println("your service charges are" + serviceCharge);
		}

	}

}

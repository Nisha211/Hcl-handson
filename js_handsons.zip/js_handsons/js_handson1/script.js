const eventNames=[];
function addEvent(){
    const eventnames=document.getElementById("eventName").value;
    if(eventNames.length===0){
        eventNames.push(eventnames);
        document.getElementById("successMessage").innerHTML="event name added successfully";
    }
    else{
        let count=0;
        for(let i=0;i<eventNames.length;i++){
            if(eventNames[i]===eventnames)
            {
                count++;
            }
        }
    if(count===0){
        eventNames.push(eventnames);
        document.getElementById("successMessage").innerHTML="event name added succesfully";
    }
    else{
        document.getElementById("successMessage").innerHTML="Event name already exists.Try with some other one";
    }
    }
}
  function displayEvents(){
      for(let i=0;i<eventNames.length;i++){
          document.getElementById("resultTable").innerHTML +="<tr><td>"+ eventNames[i] +"</td></tr>";
      }
  }



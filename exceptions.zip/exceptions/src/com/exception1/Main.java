package com.exception1;
import java.util.*;

public class Main {

	public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			int i;
			System.out.println("enter any 10 values");
			int[] arr=new int[10];
			for(i=0;i<arr.length;i++) {
				arr[i]=sc.nextInt();
				sc.nextLine();
			}
			try {
			i=0;
			for(int j=10;j>=0;j--) {
				int result=arr[i]/j;
				i++;
				System.out.println("result" +result);
				
			}
			
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("elements over");
		}

	}

}

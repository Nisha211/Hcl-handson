package com.exception5;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		try {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the number of items");
		int items=sc.nextInt();
		sc.nextLine();
		System.out.println("enter the value of n");
		int n=sc.nextInt();
		sc.nextLine();
		int cost=(items/n);
		System.out.println("cost of the items : " +cost);
		
	}
		catch(ArithmeticException e){
			System.out.println("cost of items cannot be divided by zero");
			
			
		}

}
}

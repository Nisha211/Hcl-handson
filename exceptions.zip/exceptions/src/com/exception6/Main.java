package com.exception6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException{
		try {
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("enter the itemtype details");
			String name=br.readLine();
			System.out.println("enter the deposit");
			double deposit=Double.parseDouble(br.readLine());
			System.out.println("enter the cost per day");
			double costperday=Double.parseDouble(br.readLine());
			ItemType it=new ItemType(name,deposit,costperday);
			it.display();
			
		}
		catch(NumberFormatException nfe) {
			System.out.println("string cannot be converted to integer");
		}
		// TODO Auto-generated method stub

	}

}

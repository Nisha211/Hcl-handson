package com.exception2;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
			try {
				Scanner sc=new Scanner(System.in);
				int i;
				System.out.println("enter any 10 values");
				int[] arr=new int[50];
				for(i=1;i<=10;i++) {
					arr[i]=sc.nextInt();
					sc.nextLine();
				}
				System.out.println("enter divisor");
				int a=sc.nextInt();
				sc.nextLine();
				for(i=1;i<=10;i++) {
					int result=arr[i]/a;
					System.out.println("result" +result);
					
				}
				
			}
			catch(ArithmeticException e) {
				System.out.println("cannot divide by zero");
			}


	}

}

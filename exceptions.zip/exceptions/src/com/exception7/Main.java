package com.exception7;

import java.util.*;
public class Main {

	public static void main(String[] args) {
		     Scanner sc=new Scanner(System.in);
		     try {
		    	 System.out.println("Enter an integer input");
		    	 int num=sc.nextInt();
		    	 System.out.println("the values are"+num);
		     }
		     catch(InputMismatchException e) {
		              System.out.println(e);	 
		     }

}
}

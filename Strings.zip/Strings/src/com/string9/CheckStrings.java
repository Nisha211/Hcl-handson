package com.string9;

public class CheckStrings {
	private String str1;
	public CheckStrings() {
		
	}

	public CheckStrings(String str1) {
		super();
		this.str1 = str1;
	}

	public String getStr1() {
		return str1;
	}

	public void setStr1(String str1) {
		this.str1 = str1;
	}
	public String convertString() {
		str1=str1.toUpperCase();
		return str1;
		
	
}
}

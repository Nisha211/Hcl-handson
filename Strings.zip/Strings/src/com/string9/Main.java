package com.string9;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter Humpty's sentence");
		String str1=br.readLine();
		CheckStrings h1=new CheckStrings(str1);
		String result=h1.convertString();
		System.out.println(result);
	}

}

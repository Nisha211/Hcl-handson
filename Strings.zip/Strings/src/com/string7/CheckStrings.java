package com.string7;

public class CheckStrings {
	private String str1;
	private String str2;
	private int position;
	public CheckStrings() {
		
	}
	public CheckStrings(String str1, String str2, int position) {
		super();
		this.str1 = str1;
		this.str2 = str2;
		this.position = position;
	}
	public String getStr1() {
		return str1;
	}
	public void setStr1(String str1) {
		this.str1 = str1;
	}
	public String getStr2() {
		return str2;
	}
	public void setStr2(String str2) {
		this.str2 = str2;
	}
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String insertData() {
		StringBuffer newString=new StringBuffer(str1);
		newString.insert(position-1, str2);
		str1=newString.toString();
		return str1;
		
	}
}

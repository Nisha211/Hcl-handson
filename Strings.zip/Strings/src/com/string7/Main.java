package com.string7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.string6.CheckStrings1;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter Humpty's sentence");
		String str1=br.readLine();
		System.out.println("what Dumpty's want to insert");
		String str2=br.readLine();
		System.out.println("where");
		int position=Integer.parseInt(br.readLine());
		CheckStrings s1=new CheckStrings(str1, str2, position);
		str1=s1.insertData();
		System.out.println(str1);
		

	}

}

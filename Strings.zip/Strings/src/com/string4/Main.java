package com.string4;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter humpty's sentence");
		String str1=br.readLine();
		System.out.println("enter Dumpty's sentence");
		String str2=br.readLine();
		CheckStrings s1=new CheckStrings(str1, str2);
		boolean result=s1.stringFound();
		if(result) {
			System.out.println("found");
			
		}
		else {
			System.out.println("Not found");
		}

	}

}

package com.string2;

public class CheckStrings1 {
	private String str1;

	public CheckStrings1() {

	}

	public String getStr1() {
		return str1;
	}

	public void setStr1(String str1) {
		this.str1 = str1;
	}

	public String stringReverse() {
		StringBuilder sb = new StringBuilder();
		sb.append(str1);
		sb = sb.reverse();
		str1 = sb.toString();
		return str1;

	}

}

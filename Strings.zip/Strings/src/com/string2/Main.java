package com.string2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;

import com.string1.CheckStrings;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String str1 = br.readLine();
		CheckStrings1 c = new CheckStrings1();
		c.setStr1(str1);
		str1 = c.stringReverse();
		System.out.println(str1);
	}

}

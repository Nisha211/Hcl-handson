package com.string10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter humpty's sentence");
		String str1=br.readLine();
		CheckStrings3 str=new CheckStrings3();
		str.setStr1(str1);
		str.checkUpperCase();
		if(str.checkUpperCase()) {
			System.out.println("string is in uppercase");
			
		}
		else {
			System.out.println("string is not in uppercase");
		}

	}

}

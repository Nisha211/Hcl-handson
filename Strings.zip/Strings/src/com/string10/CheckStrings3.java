package com.string10;

public class CheckStrings3 {
	private String str1;
	public CheckStrings3() {
		
	}

	public CheckStrings3(String str1) {
		super();
		this.str1 = str1;
	}

	public String getStr1() {
		return str1;
	}

	public void setStr1(String str1) {
		this.str1 = str1;
	}
	public boolean checkUpperCase() {
		int len=str1.length();
        char[] charArray = str1.toCharArray();
        
        for(int i=0; i < charArray.length; i++){

                if( !Character.isUpperCase( charArray[i] )) {
                	return false;
                
                	
                }
                	
                }
        return true;
                   
            }
}

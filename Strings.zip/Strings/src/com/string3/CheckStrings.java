package com.string3;

public class CheckStrings {
	private String str1;
	private String source;
	private String search;
	
	public CheckStrings() {
		
	}
	public CheckStrings(String str1, String source, String search) {
		super();
		this.str1 = str1;
		this.source = source;
		this.search = search;
	}
	public String getStr1() {
		return str1;
	}
	public void setStr1(String str1) {
		this.str1 = str1;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	public String replacestring() {
		String result=str1.replace(source, search);
		return result;
	}
	

}

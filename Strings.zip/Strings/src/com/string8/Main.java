package com.string8;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.string7.CheckStrings;

public class Main {

	public static void main(String[] args) throws IOException {
		String result;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter Humpty's sentence");
		String str1=br.readLine();
		System.out.println("what Dumpty's sentence");
		String str2=br.readLine();
		CheckStrings2 s2=new CheckStrings2(str1, str2);
		result=s2.checkWords();
	    System.out.println(result + " has more words");
	}

}

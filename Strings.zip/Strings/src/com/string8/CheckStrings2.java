package com.string8;

public class CheckStrings2 {
	private String str1;
	private String str2;

	public CheckStrings2() {

	}

	public CheckStrings2(String str1, String str2) {
		super();
		this.str1 = str1;
		this.str2 = str2;
	}

	public String getStr1() {
		return str1;
	}

	public void setStr1(String str1) {
		this.str1 = str1;
	}

	public String getStr2() {
		return str2;
	}

	public void setStr2(String str2) {
		this.str2 = str2;
	}

	public String checkWords() {
		int count = 0,count1=0;

		char ch[] = new char[str1.length()];
		for (int i = 0; i < str1.length(); i++) {
			ch[i] = str1.charAt(i);
			if (((i > 0) && (ch[i] != ' ') && (ch[i - 1] == ' ')) || ((ch[0] != ' ') && (i == 0)))
				count++;
		}
		char ch1[] = new char[str2.length()];
		for (int i = 0; i < str2.length(); i++) {
			ch1[i] = str2.charAt(i);
			if (((i > 0) && (ch1[i] != ' ') && (ch1[i - 1] == ' ')) || ((ch1[0] != ' ') && (i == 0)))
				count1++;
		}
		if(count==count1) {
			return str1;
		}
		else  {
			return str2;
		}
	}

}

package com.day4;

public abstract class Shape {
	public abstract double calculatePerimeter();

}

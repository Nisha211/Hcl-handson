const eventNames=[];
function pushelement(){
    document.getElementById("resultth3").innerHTML="";
    document.getElementById("eventList").innerHTML="";
    const eventnames=document.getElementById("input").value;
    if(eventNames.length===0){
        eventNames.push(eventnames);
        document.getElementById("events").innerHTML="events added successfully";
    }
    else{
        let count=0;
        for(let i=0;i<eventNames.length;i++){
            if(eventNames[i]===eventnames)
            {
                count++;
            }
        }
    if(count===0){
        eventNames.push(eventnames);
        document.getElementById("events").innerHTML="event added succesfully";
    }
    else{
        document.getElementById("events").innerHTML="Event name already exists.Try with some other one";
    }
    }
}
  function popelement(){
      document.getElementById("resultth3").innerHTML="";
      document.getElementById("eventList").innerHTML="";
      if(eventNames.length===0){
          document.getElementById("events").innerHTML="event array is empty";
      }
      else{
          eventNames.pop();
          document.getElementById("events").innerHTML="removed succesfully";

      }
     
  }
  function display(){
      if(eventNames.length===0){
          document.getElementById("resultth3").innerHTML="";
      }
      else{
          document.getElementById("resultth3").innerHTML="the events in the array";
          for(let i=0;i<eventNames.length;i++){
              document.getElementById("eventList").innerHTML += "<li>" +eventNames[i]+ "</li>" ;
          }
  }

  }




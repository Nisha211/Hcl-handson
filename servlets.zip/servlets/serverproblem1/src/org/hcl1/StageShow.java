package org.hcl1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StageShow
 */
@WebServlet("/StageShow")
public class StageShow extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public StageShow() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<center>");
		pw.println("<body>");
		pw.println("<table style=\"border: 1px solid black;border-collapse:collapse;\">\r\n" + 
				"  <tr  style=\"border: 1px solid black;border-collapse:collapse;\">\r\n" + 
				"    <th  style=\"border: 1px solid black;border-collapse:collapse;\">Name</th>\r\n" + 
				"    <th  style=\"border: 1px solid black;border-collapse:collapse;\">New YearEve</th>\r\n" + 
				"  </tr>\r\n" + 
				"  <tr  style=\"border: 1px solid black;border-collapse:collapse;\">\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">HallName</td>\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">pvr lulumall</td>\r\n" + 
				"  </tr>\r\n" + 
				"  <tr  style=\"border: 1px solid black;border-collapse:collapse;\">\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">Date</td>\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">10-10-2020</td>\r\n" + 
				"  </tr>\r\n" + 
				"  <tr  style=\"border: 1px solid black;border-collapse:collapse;\">\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">starttime</td>\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">10:00:00</td>\r\n" + 
				"  </tr>\r\n" + 
				"  <tr  style=\"border: 1px solid black;border-collapse:collapse;\">\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">endtime</td>\r\n" + 
				"    <td  style=\"border: 1px solid black;border-collapse:collapse;\">12:00:00</td>\r\n" + 
				"  </tr>\r\n" + 
				"</table>");
		pw.println("</center>");
		pw.println("</body>");
	}

}

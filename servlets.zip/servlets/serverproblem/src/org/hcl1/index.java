package org.hcl1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Index")
public class index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public index() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<center>");
		pw.println("<body>");
		pw.println("<h1 style=\"color:pink;\">Welcome to Hall Paradise</h1>");
		pw.println("<p>The type of events are</p>");
		pw.println("<ul>\r\n" + 
				"  <li>Exhibition</li>\r\n" + 
				"  <li>Stage show</li>\r\n" + 
				"</ul>");
		pw.println("</center>");
	}

	/*protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);*/
	}


package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Display() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String Name=request.getParameter("name");
		String PhoneNumber=request.getParameter("phonenumber");
		String Email=request.getParameter("email");
		String City=request.getParameter("city");
		pw.println("<h1>User Details</h1>");
		pw.println("<table border='1'>");
		pw.println("<tr>");
		pw.println("<td>Name</td>\r\n"
				+ "<td>PhoneNumber</td>\r\n"
				+ "<td>Email</td>\r\n"
				+ "<td>City</td>");
		pw.println("</tr>");
		pw.println("<tbody>");
		pw.println("<td>"+Name+"</td><td>"+PhoneNumber+"</td><td>"+Email+"</td><td>"+City+"</td>");
		pw.println("</tbody>");
		pw.println("</table>");
		pw.close();
	
		
	}

}

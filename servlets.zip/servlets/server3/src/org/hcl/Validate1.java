package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Validate1
 */
@WebServlet("/Validate1")
public class Validate1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Validate1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String EventName = request.getParameter("eventname");
		String HallName = request.getParameter("hallname");
		String EventType = request.getParameter("eventtype");
		String Details = request.getParameter("details");
		String Owner = request.getParameter("owner");
		String StartDate = request.getParameter("startdate");
		String EndDate = request.getParameter("enddate");
		pw.println("<center>");
		if (EventName.isEmpty() || HallName.isEmpty() || EventType==null || Details.isEmpty() || Owner.isEmpty()
				|| StartDate.isEmpty() || EndDate.isEmpty()) {
			RequestDispatcher dispatch = request.getRequestDispatcher("./Index");
			pw.println("<div>");
			if (EventName.isEmpty()) {
				pw.println("<h3 style='color:red'>Enter event name</h3>");
			}
			if (HallName.isEmpty()) {
				pw.println("<h3 style='color:red'>Enter hall name</h3>");
			}
			if (EventType.isEmpty()) {
				pw.println("<h3 style='color:red'>Enter event type</h3>");
			}
			if (Details.isEmpty()) {
				pw.println("<h3 style='color:red'>Enter event details</h3>");
			}
			if (Owner.isEmpty()) {
				pw.println("<h3 style='color:red'>Enter owner name</h3>");
			}
			if (StartDate.isEmpty()) {
				pw.println("<h3 style='color:red'>Enter start date</h3>");
			}
			if (EndDate.isEmpty()) {
				pw.println("<h3 style='color:red'>Enter end date</h3>");
			}
			pw.println("</div>");
			dispatch.include(request, response);
		} else {
			pw.println("<h1 style=\"color:green;\">Event created successfully</h1>");
			pw.println("<h3>Event Details</h3>");
			pw.println("<table border='1'>");
			pw.println("<tr><td>EventName</td><td>"+EventName+"</td></tr>");
			pw.println("<tr><td>HallName</td><td>"+HallName+"</td></tr>");
			pw.println("<tr><td>EventType</td><td>"+EventType+"</td></tr>");
			pw.println("<tr><td>Details</td><td>"+Details+"</td></tr>");
			pw.println("<tr><td>Owner</td><td>"+Owner+"</td></tr>");
			pw.println("<tr><td>StartDate</td><td>"+StartDate+"</td></tr>");
			pw.println("<tr><td>EndDate</td><td>"+EndDate+"</td></tr>");
			
	}
	}

}

package org.hcl;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/Index")
public class Index extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public Index() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<h1>Event creation</h1>");
		pw.println("<table>");
		pw.println("<form action=\"./Validate1\"method=\"post\">");
		pw.println("<tr><td>EventName</td><td><input type=\"text\" name=\"eventname\"></td></tr>");
		pw.println("<tr><td>HallName</td><td><input type=\"text\" name=\"hallname\"></td></tr>");
		pw.println("<tr><td>EventType</td><td><input type=\"radio\" value=\'Exhibition' name=\"type\">Exhibition<br>"
				+ "<input type=\"radio\" value=\'StageShow' name=\"type\">stageshow</td></tr>");
		pw.println("<tr><td>Details</td><td><input type=\"text\" name=\"details\"></td></tr>");
		pw.println("<tr><td>OwnerName</td><td><input type=\"text\" name=\"ownername\"></td></tr>");
		pw.println("<tr><td>StartDate</td><td><input type=\"text\" name=\"startdate\"></td></tr>");
		pw.println("<tr><td>EndDate</td><td><input type=\"text\" name=\"enddate\"></td></tr>");
		pw.println("<tr><td></td><td><input type=\"submit\" id=\"submit\" value=\"create\"></td></tr>");
		pw.println("</form>");
		pw.println("</table>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		pw.println("<h1>Event creation</h1>");
		pw.println("<table>");
		pw.println("<form action=\"./Validate1\"method=\"post\">");
		pw.println("<tr><td>EventName</td><td><input type=\"text\" name=\"eventname\"></td></tr>");
		pw.println("<tr><td>HallName</td><td><input type=\"text\" name=\"hallname\"></td></tr>");
		pw.println("<tr><td>EventType</td><td><input type=\"radio\" value=\'Exhibition' name=\"type\">Exhibition<br>"
				+ "<input type=\"radio\" value=\'StageShow' name=\"type\">stageshow</td></tr>");
		pw.println("<tr><td>Details</td><td><input type=\"text\" name=\"details\"></td></tr>");
		pw.println("<tr><td>OwnerName</td><td><input type=\"text\" name=\"ownername\"></td></tr>");
		pw.println("<tr><td>StartDate</td><td><input type=\"text\" name=\"startdate\"></td></tr>");
		pw.println("<tr><td>EndDate</td><td><input type=\"text\" name=\"enddate\"></td></tr>");
		pw.println("<tr><td></td><td><input type=\"submit\" id=\"submit\" value=\"create\"></td></tr>");
		pw.println("</form>");
		pw.println("</table>");
	}

}

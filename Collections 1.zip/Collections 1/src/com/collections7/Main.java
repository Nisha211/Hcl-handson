package com.collections7;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

	public static void main(String[] args) throws IOException{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<User> l=new ArrayList<>();
		LinkedHashMap<String,String> l1=new LinkedHashMap<>();
		System.out.println("enter the number of users");
		int n=Integer.parseInt(br.readLine());
		for(int i=0;i<n;i++) {
			System.out.println("enter the details of user" +(i+1));
			String str=br.readLine();
			String details[]=str.split(",");
			l.add(new User(details[0],details[1],details[2],details[3]));
			
		}
		Collections.sort(l);
		Collections.reverse(l);
		for(int i=0;i<n;i++) {
			l1.put(l.get(i).getName(),l.get(i).getMobileNumber());
			
		}
		Set values=l1.entrySet();
		Iterator<LinkedHashMap> itr=values.iterator();
		while(itr.hasNext()) {
			Map.Entry m=(Map.Entry)itr.next();
			System.out.format("%-15s  %-15s" , m.getKey() ,m.getValue());
			System.out.println();
		}

	}

}

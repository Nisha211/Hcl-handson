package com.collections3;
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

import com.collections2.Stall;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArrayList <Hall> h1=new ArrayList<>();
		System.out.println("enter the stall details");
		int a=Integer.parseInt(br.readLine());
		for(int i=0;i<a;i++) {
			System.out.println("enter the details of hall " +i);
			String str=br.readLine();
			String details[]=str.split(",");
			h1.add(new Hall(details[0],Double.parseDouble(details[1]),Double.parseDouble(details[2]),details[3]));
			
			
		}
		System.out.format("%-15s %-20s %-15s %s", "name","contactNumber","costperday","ownername");
		System.out.println();
		Collections.sort(h1);
		Iterator<Hall> itr=h1.iterator();
		while(itr.hasNext()) {
			Hall h2=itr.next();
			System.out.println(h2);
		}
		
		 

	}

}

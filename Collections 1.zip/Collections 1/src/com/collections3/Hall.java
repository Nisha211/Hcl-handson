package com.collections3;
import java.util.*;

public class Hall implements Comparable{
	private String name;
	private double ContactNumber;
	private double costPerday;
	private String ownerName;
	public Hall() {
		
	}
	public Hall(String name, double contactNumber, double costPerday, String ownerName) {
		super();
		this.name = name;
		ContactNumber = contactNumber;
		this.costPerday = costPerday;
		this.ownerName = ownerName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getContactNumber() {
		return ContactNumber;
	}
	public void setContactNumber(double contactNumber) {
		ContactNumber = contactNumber;
	}
	public double getCostPerday() {
		return costPerday;
	}
	public void setCostPerday(double costPerday) {
		this.costPerday = costPerday;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	@Override
	public int compareTo(Object o) {
		Hall h2=(Hall)o;
		if(this.costPerday>h2.getCostPerday()) {
			return 1;
		}
		else {
			return -1;
		}
	}
	public String toString() {
		return name +"\t"+ ContactNumber +"\t"+costPerday +"\t"+ownerName;
	}
	
	
	
	

}

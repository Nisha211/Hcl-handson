package com.collections6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<List<Integer>> daylist=new ArrayList<>();
		List<Integer> showlist=new ArrayList<>();
		System.out.println("Enter of count of booked tickets");
		int a=Integer.parseInt(br.readLine());
		String str;
		for(int i=0;i<a;i++) {
			System.out.println("on Day " +(i+1));
			str=br.readLine();
			String details[]=str.split(",");
			showlist.add(100-Integer.parseInt(details[0]));
			showlist.add(100-Integer.parseInt(details[1]));
			showlist.add(100-Integer.parseInt(details[2]));
			showlist.add(100-Integer.parseInt(details[3]));	
		}
		int b=0;
		for(int i=0;i<a;i++) {
			daylist.add(showlist.subList(b, b+4));	
			b=b+4;
		}System.out.println(daylist);
		String answer="";
		do {
			System.out.println("enter the day to know its remaining ticket count");
			int i=Integer.parseInt(br.readLine());
			System.out.println("remaining tickes " +daylist.get(i-1));
			System.out.println("do you want to contnue");
			answer=br.readLine();
			
		}while(answer.equals("yes"));
	}

}

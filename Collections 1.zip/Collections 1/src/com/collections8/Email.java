package com.collections8;

import java.util.Comparator;

public class Email implements Comparator {

	@Override
	public int compare(Object o, Object o1) {
		User u1=(User)o;
		User u2=(User)o1;
		return u1.getEmail().compareTo(u2.getEmail());
	}
	
	

}

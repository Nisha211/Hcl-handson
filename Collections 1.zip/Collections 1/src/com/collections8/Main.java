package com.collections8;
import java.util.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List<User> u=new ArrayList<>();
		System.out.println("enter the number of users");
		int a =Integer.parseInt(br.readLine());
		for(int i=0;i<a;i++) {
			System.out.println("enter the user" +i+ "details");
			String str=br.readLine();
			String details[]=str.split(",");
			u.add(new User(details[0],details[1],details[2],details[3]));

	}
		System.out.format("%-15s %-20s %-15s %s", "name","email","username","password");
		System.out.println();
		System.out.println("Search By 1.Name" +"\n"+ "2.E-mail");
		int b=Integer.parseInt(br.readLine());
		switch(b) {
		case 1:
			Collections.sort(u);
			System.out.println("enter name");
			int n=Collections.binarySearch(u, new User(br.readLine(),null,null,null),null);
			if(n<0) {
				System.out.println("name not found");
			}
			else {
				System.out.format("%-15s %-20s %-15s %s", "name","email","username","password");
				System.out.println();
				User a2=u.get(n);
				System.out.println(a2);
			}
			break;
			

		case 2:
			Comparator c=new Email();
			u.sort(c);
			int n1=Collections.binarySearch(u, new User(null,br.readLine(),null,null),c);
			if(n1<0) {
				System.out.println("email not found");
			}
			else {
				System.out.format("%-15s %-20s %-15s %s", "name","email","username","password");
				System.out.println();
				User a3=u.get(n1);
				System.out.println(a3);
			}
			break;
		
		

	}
	}
}

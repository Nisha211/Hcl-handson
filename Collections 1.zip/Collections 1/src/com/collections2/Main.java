package com.collections2;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArrayList <Stall> s1=new ArrayList<>();
		System.out.println("enter the stall details");
		int a=Integer.parseInt(br.readLine());
		for(int i=0;i<a;i++) {
			System.out.println("enter the stall " + i + " detail");
			String str=br.readLine();
			String details[]=str.split(",");
			s1.add(new Stall(details[0],details[1],details[2],details[3]));
			
			
		}
		System.out.format("%-15s %-20s %-15s %s", "name","detail","type","ownername");
		System.out.println();
		
		Iterator<Stall> itr=s1.iterator();
		while(itr.hasNext()) {
			Stall s=itr.next();
			if(s.getName().startsWith("test")) {
				itr.remove();
				
			}
			else {
				System.out.println(s);
			}
			
		}
	}

}

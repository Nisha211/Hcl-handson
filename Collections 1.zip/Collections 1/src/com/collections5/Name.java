package com.collections5;
import java.util.Comparator;

public class Name implements Comparator<User> {

	@Override
	public int compare(User a, User b) {
		
		return a.getName().compareTo(b.getName());
	}
	
	

}

package com.collections5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

import com.collections4.Address;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		List <User> u=new ArrayList<>();
		System.out.println("enter the address details");
		int a=Integer.parseInt(br.readLine());
		for(int i=0;i<a;i++) {
			System.out.println("enter the address details " +i);
			String str=br.readLine();
			String details[]=str.split(",");
			u.add(new User(details[0],details[1],details[2],details[3]));

	}
		System.out.format("%-15s %-20s %-15s %s", "name","email","username","password");
		System.out.println();
		System.out.println("Sort By 1.Name" +"\n"+ "2.E-mail");
		int b=Integer.parseInt(br.readLine());
		switch(b) {
		case 1:
			
			Collections.sort(u,new Name());
			break;
		case 2:
			Collections.sort(u,new Email());
			break;
		case 3:
			System.out.println("invalid choice");
			
		}
		for(User u1:u) {
			System.out.format("%-15s %-20s %-15s %s",u1.getName(),u1.getEmail(),u1.getUsername(),u1.getPassword());
			System.out.println();
		}
		

}
}

package com.collections1;
import java.util.*;
public class TicketBooking implements Comparator {
	private String customerName;
	private int price;
	public TicketBooking() {
		
	}
	public TicketBooking(String customerName, int price) {
		super();
		this.customerName = customerName;
		this.price = price;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	@Override
	public int compare(Object o1, Object o2) {
		TicketBooking t1=(TicketBooking) o1;
		TicketBooking t2=(TicketBooking)  o2;
		if(t1.getPrice() > t2.getPrice()) {
			return 1;
		}
		else 
			return -1;
	}
	
	
	

}

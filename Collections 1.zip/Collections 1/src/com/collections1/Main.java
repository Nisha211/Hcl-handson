package com.collections1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
public class Main {

	public static void main(String[] args) throws IOException{
		ArrayList<TicketBooking> ticket=new ArrayList<>();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter the number of customers");
		int n=Integer.parseInt(br.readLine());
		String str;;
		System.out.println("enter the booking price accoridngly with customer name with CSV format");
		if(n>0) {
			for(int i=0;i<n;i++) {
				 str=br.readLine();
				 String details[]=str.split(",");
				 ticket.add(new TicketBooking(details[0],Integer.parseInt(details[1])));
			}
		Comparator c=new TicketBooking();
		TicketBooking t1=Collections.min(ticket,c);
		System.out.println(t1.getCustomerName() +"spends a minimum amount"+t1.getPrice());
		TicketBooking t2=Collections.max(ticket,c);
		System.out.println(t2.getCustomerName() +"gets a maximum amount" +t2.getPrice());
		
		}
		else {
			System.out.println("enter a valid names");
		}
	
		
		
		
	}
}


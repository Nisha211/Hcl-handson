package com.collections4;

public class Address implements Comparable {
	private String UserName;
	private String AddressLine1;
	private String AddressLine2;
	private int pincode;
	public Address() {
		
	}
	public Address(String userName, String addressLine1, String addressLine2, int pincode) {
		super();
		UserName = userName;
		AddressLine1 = addressLine1;
		AddressLine2 = addressLine2;
		this.pincode = pincode;
	}
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getAddressLine1() {
		return AddressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		AddressLine1 = addressLine1;
	}
	public String getAddressLine2() {
		return AddressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		AddressLine2 = addressLine2;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	@Override
	public int compareTo(Object o) {
		Address a=(Address) o;
		if(this.pincode<a.getPincode()) {
			return 1;
		}
		else if(this.pincode>a.getPincode()){
			return -1;
		}
		else if(this.pincode==a.getPincode()) 
			a.getAddressLine1().compareTo(this.AddressLine1);
			return 0;
		
	}
	public String toString() {
		return UserName +"\t"+ AddressLine1 +"\t"+ AddressLine2 +"\t" + pincode;
	}
	
	
	

}

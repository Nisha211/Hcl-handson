package com.collections4;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Main {

	public static void main(String[] args) throws IOException {
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		ArrayList <Address> address=new ArrayList<>();
		System.out.println("enter the address details");
		int a=Integer.parseInt(br.readLine());
		for(int i=0;i<a;i++) {
			System.out.println("enter the address details " +i);
			String str=br.readLine();
			String details[]=str.split(",");
			address.add(new Address(details[0],details[1],details[2],Integer.parseInt(details[3])));	
		
		}
		System.out.format("%-15s %-20s %-15s %s", "username","addressline1","addressline2","pincode");
		System.out.println();
		Collections.sort(address);
		Iterator<Address> itr=address.iterator();
		while(itr.hasNext()) {
			Address a2=itr.next();
			System.out.println(a2);
	}
	}

}

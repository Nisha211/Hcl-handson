package com.code5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) throws NullPointerException,IOException{
		ApplicationContext context=new ClassPathXmlApplicationContext("Context5.xml");
		Owner owner=context.getBean("owner",Owner.class);
		BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter name,password and mobilenumber of the user");
		String name = reader.readLine();
		String password = reader.readLine();
		String mobileNumber = reader.readLine();
		owner.setDetails(name, password, mobileNumber);
		owner.display();
		
	

	}

}

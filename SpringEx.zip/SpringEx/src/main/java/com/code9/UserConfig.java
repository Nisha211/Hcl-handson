package com.code9;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class UserConfig {
	@Bean(name = "user")
	public User getuser() {
		User user = new User();
		user.setName("Jegan");
		user.setAge(24);
		user.setCity("Chennai");
		return user;

	}

	@Bean(name = "orderone")
	public Order getorder() {
		Order order = new Order();
		order.setItemName("item1");
		order.setPrice(230.07);
		return order;
	}

	@Bean(name = "ordertwo")
	public Order getorder1() {
		Order order = new Order();
		order.setItemName("item2");
		order.setPrice(230.07);
		return order;
	}

}

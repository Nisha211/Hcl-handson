package com.code9;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("com.code9");
		User user = context.getBean(User.class, "user");
		user.display();
		((AnnotationConfigApplicationContext) context).close();
	}

}

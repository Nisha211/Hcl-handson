package com.revenue;

import java.util.ArrayList;

public class CourseList {
	double value = 0;
	ArrayList<Course> courseList = new ArrayList();

	public void insert(Course course) {
		courseList.add(course);
	}

	public void revenue() {
		for (Course course : courseList) {
			value = value + course.getFee();

		}
		double totalrevenue = (200) * 0.2 * value;
		System.out.println("the total revenue is" + totalrevenue);

	}

}

package org.code7;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("org.code7");
		Box box = context.getBean(Box.class, "box");
		box.display();
		((AnnotationConfigApplicationContext) context).close();

	}

}

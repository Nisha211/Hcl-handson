package org.code7;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;

public class Box {
	private User user;
	private int length;
	private int width;

	public Box() {
		// TODO Auto-generated constructor stub
	}

	public Box(User user, int length, int width) {
		super();
		this.user = user;
		this.length = length;
		this.width = width;
	}

	public User getUser() {
		return user;
	}

	@Autowired
	@Required
	public void setUser(User user) {
		this.user = user;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public void display() {
		System.out.println("Box :");
		System.out.println("length : " + length);
		System.out.println("width : " + width);
		user.display();
		System.out.println("The hall of length " + length + " and " + width + " is owned by " + user.getName());

	}

}

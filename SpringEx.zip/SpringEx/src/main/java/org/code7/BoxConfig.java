package org.code7;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration

public class BoxConfig {
	@Bean(name = "box")
	public Box getbox() {
		Box box = new Box();
		box.setLength(12);
		box.setWidth(10);
		return box;

	}

	@Bean(name = "user")
	public User getuser() {
		User user = new User();
		user.setName("Surya");
		user.setPassword("Surya");
		return user;
	}
}

package org.courseGeneartion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CourseConfig {
	@Bean(name = "course1")
	public Course getcourse1() {
		Course course1 = new Course();
		course1.setName("java");
		course1.setMentor("Sathish");
		course1.setFee(1000.00);
		return course1;

	}

	@Bean(name = "course2")
	public Course getcourse2() {
		Course course2 = new Course();
		course2.setName("Selenium");
		course2.setMentor("Kanimozhi");
		course2.setFee(2000.00);
		return course2;
	}

	@Bean(name = "course3")
	public Course getcourse3() {
		Course course3 = new Course();
		course3.setName("python");
		course3.setMentor("Arun");
		course3.setFee(500.00);
		return course3;
	}

}

package org.code6;

import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmpConfig {
	@Bean(name = "employee")
	public Employee getEmployee() {
		Employee employee = new Employee();
		employee.setEmployeeName("Sathish");
		ArrayList<String> employeeMobileNumber = new ArrayList<String>();
		employeeMobileNumber.add("9566259957");
		employeeMobileNumber.add("9566259958");
		employeeMobileNumber.add("9566259959");
		employee.setEmployeeMobileNumber(employeeMobileNumber);
		employee.setEmployeeSalary(45000);
		employee.setEmployeeEmail("sathish@gmail.com");

		return employee;

	}

	@Bean(name = "address")
	public Address getAddress() {
		Address address = new Address();
		address.setLine1("2/15 AnnaNagar");
		address.setLine2("Kaveripatinam");
		address.setCity("Krishnagiri");
		address.setPincode("63512");
		return address;
	}

}

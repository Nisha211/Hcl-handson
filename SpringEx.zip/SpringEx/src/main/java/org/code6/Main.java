package org.code6;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) throws NullPointerException, IOException {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("org.code6");
		Employee employee = context.getBean(Employee.class, "employee");
		employee.display();
		((AnnotationConfigApplicationContext) context).close();

	}

}

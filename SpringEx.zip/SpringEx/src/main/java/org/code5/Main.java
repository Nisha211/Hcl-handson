package org.code5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext("org.code5");
		Owner owner = context.getBean(Owner.class);
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter name,password and mobilenumber of the user");
		String name = reader.readLine();
		String password = reader.readLine();
		String mobileNumber = reader.readLine();
		owner.setDetails(name, password, mobileNumber);
		owner.display();

	}

}

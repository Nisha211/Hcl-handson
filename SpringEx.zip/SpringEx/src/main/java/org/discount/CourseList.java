package org.discount;

import java.util.ArrayList;

public class CourseList {
	ArrayList<Course> courseList = new ArrayList();

	public void insert(Course course) {
		courseList.add(course);
	}

	public void discount() {
		double maxfee = 0;
		double minfee = 9999;
		String maxName = null;
		String minName = null;
		for (Course course : courseList) {
			if (course.getFee() > maxfee) {
				maxfee = course.getFee();
				maxName = course.getName();
			}

		}
		for (Course course : courseList) {
			if (course.getFee() < minfee) {
				minfee = course.getFee();
				minName = course.getName();
			}

		}
		System.out.println(" Discount " + ((0.1) * maxfee) + " for " + maxName);
		System.out.println(" Discount " + ((0.05) * minfee) + " for " + minName);

	}
}

package org.course;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) throws NumberFormatException, IOException {
		CourseList courselist = new CourseList();
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		ArrayList<String> budgetlist = new ArrayList<>();
		ApplicationContext context = new ClassPathXmlApplicationContext("courseContext.xml");
		Course course1 = context.getBean("courses1", Course.class);
		Course course2 = context.getBean("courses2", Course.class);
		Course course3 = context.getBean("courses3", Course.class);
		System.out.println("Enter your budget");
		Double budget = Double.parseDouble(reader.readLine());
		courselist.insert(course1);
		courselist.insert(course2);
		courselist.insert(course3);
		budgetlist = courselist.noOfcourse(budget);
		if (budgetlist.isEmpty()) {
			System.out.println("No course available");
		} else {
			for (String values : budgetlist) {
				System.out.println(values);
			}
		}

		((ClassPathXmlApplicationContext) context).close();
	}

}
